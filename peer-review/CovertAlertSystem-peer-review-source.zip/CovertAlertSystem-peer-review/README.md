# CovertAlertSystem peer-review source snapshot

This archive is a source snapshot for peer review of the CovertAlertSystem
web console, API, durable CAS contracts, and disposable Android Gate 0A
proxy-launch harness. It is **not** a production release, deployment bundle,
or proof of Gate 0A hardware validation.

## Product scope

CovertAlertSystem records readiness and feasibility evidence for a managed
Pixel deployment. The current review surface includes a React web console,
an Express/PostgreSQL API with durable incident and outbox records, generated
API contracts, and a local-only Android experiment that measures the
proxy-to-cover-app transition.

The native Gate 0A package deliberately has no SMS, network, location,
camera, microphone, evidence capture, recipient, or production covert
behavior. Imported reports remain **INCONCLUSIVE** until a person reviews the
physical observations.

## Source map

| Archive path | Review focus |
| --- | --- |
| `source/package.json`, `source/pnpm-*.yaml` | Workspace manifests and reproducible dependency graph |
| `source/artifacts/api-server/` | Express routes, Gate 0A import validation, durable CAS state, outbox worker, and tests |
| `source/artifacts/covert-alert-system/` | React/Vite console, gates/import UI, generated guide, and guide generator |
| `source/lib/api-spec/` | OpenAPI source of truth, including the CAS Gate 0A report contract |
| `source/lib/api-client-react/` | Generated React API client and types |
| `source/lib/api-zod/` | Generated Zod schemas and types |
| `source/lib/db/` | Drizzle/PostgreSQL schema and database package |
| `source/artifacts/covert-alert-system/android-test-package/` | Disposable Android harness, run notes, and ADB measurement script |
| `source/attached_assets/` | MVP handoff and product constraints |

## Quick start

Prerequisites:

- Node.js 24 and pnpm compatible with the lockfile.
- PostgreSQL with `initdb`, `pg_ctl`, and `createdb` on PATH. No
  credentials, database contents, or pre-existing database are needed for the
  contract checks.
- A normal web review can use the console and API in separate processes.

From the extracted archive root, enter the preserved workspace tree:

```sh
cd source
pnpm install --frozen-lockfile
pnpm run typecheck
pnpm run build
pnpm --filter @workspace/api-server run test
```

To run the services in the workspace environment:

```sh
PORT=5000 pnpm --filter @workspace/api-server run dev
PORT=5173 BASE_PATH=/ pnpm --filter @workspace/covert-alert-system run dev
```

The API serves under `/api`; the web console expects the API at the same
origin through the configured preview/proxy. The API contract command above
is isolated: it reserves a local port, creates a temporary PostgreSQL cluster
under the operating system temporary directory, creates the
`cas_contract_test` database, applies the Drizzle schema, and runs the Gate
0A import plus incident/outbox/concurrency checks with a local
`DATABASE_URL`. It does not read or mutate an inherited database URL.
The cluster is stopped and its temporary directory is removed in a
`finally` cleanup boundary after the test process exits. If PostgreSQL is
not installed, the command stops before running tests and reports the
prerequisite.

To regenerate the printable guide, use:

```sh
pnpm --filter @workspace/covert-alert-system run generate:gate0a
```

The generator uses headless Chromium. The checked-in PDF is the review
deliverable and should remain available if Chromium is not installed.

## Gate 0A hardware boundary

The native package is disposable and targets a pinned Google Pixel 8a,
stock Android, API 35. A physical run requires an approved hardware
workstation with JDK 17, Android SDK/API 35, Gradle, ADB, and an authorized
managed Pixel. An emulator, source inspection, or a screenshot cannot replace
the required launch, lock-screen, reboot, task, Recents, Back, and observer
evidence. Do not create synthetic reports or timing samples when the device
or SDK is unavailable.

Read `artifacts/covert-alert-system/android-test-package/README.md` and
`attached_assets/CovertAlertSystem_Pixel_MVP_Agentic_Handoff_1787405922227.md`
before any physical run. The printable checklist is
`artifacts/covert-alert-system/public/gate0a-run-guide.pdf`.

## Focused review checklist

1. Trace the Gate 0A report from the native JSON generator through
   `source/lib/api-spec/openapi.yaml`, API validation, and the console import
   path. Confirm malformed and unsafe reports are rejected and accepted
   reports remain inconclusive.
2. Review incident trigger idempotency, append-only event recording, and
   independent SMS/XMPP outbox rows in
   `source/artifacts/api-server/src/routes/cas.ts`.
3. Inspect the Drizzle schema for durable incident, event, outbox, setup, and
   gate evidence records in `source/lib/db/src/schema/cas.ts` without
   expecting database contents in this archive.
4. Review the native harness safety boundary and verify it does not claim
   production covert behavior or automatic pass results.
5. Confirm the web UI distinguishes sample data from measured physical
   evidence and prevents imported Gate 0A evidence from creating a GO result.
6. Run typecheck/build and the isolated API contract command with the required
   dependencies; record any environment-blocked result separately.

## Explicit exclusions

This source snapshot excludes dependency trees, build output, caches, VCS
metadata, local task/agent state, Replit artifact metadata, environment
files, keys/certificates, database files/dumps, logs, runtime data, and the
unrelated mockup Canvas artifact. It contains no credentials, API keys,
session values, or database contents.
