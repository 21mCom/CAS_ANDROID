# CAS Pixel Gate 0A test package

Disposable native Android harness for the first physical run. It targets the
approved physical device (**Google Pixel 11, stock Android, API 35 or newer**)
while preserving the pinned **Pixel 8a/API 35 emulator** as simulation-only
evidence. It tests only the proxy-to-cover-app transition.

## Safety boundary

Gate 0A harness runs have no SMS, network, location, camera, microphone,
evidence capture, incident service, recipient, or production covert behavior.
The `DeviceAdminReceiver` declares no policies; its only purpose is to report
whether the package was provisioned as device owner during the experiment.
All timestamps and outcomes remain in device-local `SharedPreferences`.

Separately from the harness, the MVP alert mode (see MVP-HANDOFF-WINDOWS.md)
makes one HTTPS POST to the configured CAS server and texts the configured
responder numbers directly from the handset's SIM (device-direct SMS), then
reports the outcome back to the server. That path never runs during Gate 0A
harness runs, and the harness report filter excludes its journal events.

## Build and install

From this directory, with the Android SDK platform and JDK declared in
`tool-requirements.json`:

```sh
gradle :app:assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

There is intentionally no Gradle wrapper checked in; use the Android toolchain
provided by the hardware-run workstation. The expected Gradle release is
declared once in `gradle-version.txt` in this directory: the GitHub Actions
build reads it to install Gradle, and the Windows preflight reads it to warn
when the workstation Gradle major.minor differs from the release CI builds
with. Update that one file to move both sides to a new Gradle release.

The other workstation prerequisites are declared the same way in
`tool-requirements.json` in this directory: the minimum JDK major version, the
Android SDK platform (`android-<apiLevel>`), and the minimum build-tools
release. The GitHub Actions build reads it to select the JDK, install and
verify the SDK platform/build-tools, and pick the emulator API level; the
Gradle build reads it for `compileSdk`; and the Windows preflight reads it for
every Java/SDK/build-tools check and for the `-PrepareSdk` package list.
Update that one file to move these consumers to new prerequisite levels; do
not edit the docs or scripts to match.

The pinned-device checks follow the same declaration: the pinned Pixel 8a
emulator contract (owned by `scripts/pixel-emulator.ps1`, including the
`system-images;android-<apiLevel>` package the preflight installs in emulator
mode) and the Pixel 11 minimum-API gate in `scripts/pixel11-gate0a.ps1` both
derive their API level from `tool-requirements.json`, so a platform bump moves
them with it. One baseline is deliberately fixed and does not follow this
declaration: the app's `minSdk`/`targetSdk`, which pin the approved Pixel 11
device contract in `app/build.gradle.kts`. Change that only through its
owning file and docs.

Two build gates protect this package after the 2026-09-14 field run shipped
Kotlin that had never compiled:

- The GitHub Actions workflow `Android test package build`
  (`.github/workflows/android-test-package-build.yml`) runs
  `gradle :app:assembleDebug` on every change under this directory and
  verifies the built APK's `PROXY_TRIGGER` filter declares
  `CATEGORY_DEFAULT`.
- `scripts/package-windows-test-kit.ps1` builds the debug APK before staging
  the ZIP and refuses to package when the build fails (or when Gradle is not
  available). Pass `-SkipApkBuild` only when CI has already passed on the
  exact revision being packaged.

The `adb install -r` command above is a separate, explicit operator action
after the workstation preflight passes. The Windows preflight never runs it and
never uninstalls an APK.

## ADB measurement harness

`scripts/measure-gate0a.sh` is the repeatable host-side runner for the
disposable package. It validates the authorized ADB target before making any
device change and writes a structured evidence bundle under
`gate0a-results/<UTC timestamp>-<process id>/`.

The harness requires an explicit identity confirmation. Full runs also require
`--confirm-destructive`, because they force-stop the test package, exercise
screen state, and reboot the target. It never clears app data, changes Device
Owner policy, sends SMS/XMPP, or enables production behavior.

For a pinned emulator rehearsal:

```sh
scripts/measure-gate0a.sh \
  --target emulator \
  --serial emulator-5554 \
  --confirm-device CAS_Pixel_8a_API_35 \
  --confirm-destructive
```

For a confirmed Pixel run that builds and installs the disposable APK:

```sh
scripts/measure-gate0a.sh \
  --build \
  --install \
  --serial <authorized-serial> \
  --confirm-device "Pixel 11" \
  --confirm-destructive
```

On Windows, prefer the guarded wrappers:

```text
scripts\run-pixel11-qualification.cmd
scripts\run-pixel11-full.cmd
```

The qualification wrapper builds and installs the package and performs one
repeat. Review its evidence before using the full wrapper, which performs the
200-repeat run. Both wrappers verify the Pixel 11 model and API level, require
exact operator confirmation, and stop when the ADB target is ambiguous.

Use `--repeat 200` (the default) for the required repeat-launch series.
`--skip-reboot` is available when reboot is not approved and records reboot
recovery as `inconclusive`; it does not claim that the reboot check passed.
Even with `--skip-reboot`, `--confirm-destructive` is required because clean
starts and the process-interruption check use `am force-stop`.
`--non-interactive` skips the operator-controlled lock/unlock prompts and
records those screen-state observations as `inconclusive`.

The run sequence is explicit and ordered:

1. Build (when `--build` is supplied), validate the target, confirm identity,
   and optionally install/identify `com.covertalert.pixeltest`.
2. Clean-start cold launch, warm launch, Back, Home, and Recents.
3. Operator-confirmed unlocked, locked, and post-unlock launches.
4. `am force-stop` process interruption and recovery launch.
5. Confirmed reboot, boot-completion/package recovery, and recovery launch.
6. A clean repeat-launch boundary followed by the requested number of launches.

Each launch records host timestamps, `am start -W` status/timings, task and
process observations, a filtered logcat snapshot, and (for named samples plus
the first/last repeat) a screenshot. The bundle contains:

| File or directory | Contents |
| --- | --- |
| `report.json` | CAS-importable `cas-gate0a-report-v2` report with target, preflight, safety, timestamps, normalized outcomes, and unresolved warnings |
| `report.md` | Human-readable copy of the same run classification, preflight table, safety boundary, and evidence references |
| `events.ndjson` | One structured pass/fail/inconclusive event per check |
| `environment.tsv` | Device identity and evidence-class metadata |
| `launch/` | Raw `am start -W` output for each launch |
| `tasks/` | Activity, Recents, and package-process snapshots |
| `screenshots/` | PNG screen observations retained by the run |
| `logcat/` | Filtered ActivityManager and disposable-package logcat |
| `host.log` | Operator-facing timestamps and command milestones |

The harness stops with `BLOCKED` for a missing, unauthorized, offline, or
unexpected target. Emulator output is labeled `simulated-emulator`; it is not
physical Pixel evidence and cannot establish Gate 0A readiness.

### CAS handoff

After a completed run, use the files in the printed run directory.

Alert-channel work (MVP alert loop, device-direct SMS/WhatsApp, XMPP/email
provider drills) lives in `MVP-HANDOFF-WINDOWS.md`; the full verification
matrix for the Windows operator is `HANDOFF-TEST-KIT.md` with
`scripts\cas-api-drills.ps1`.

```text
gate0a-results/<UTC timestamp>-<process id>/report.json
gate0a-results/<UTC timestamp>-<process id>/report.md
```

Review `report.md`, the matching Windows preflight JSON/Markdown files, and the
raw log, task, screenshot, and launch references before importing. In the CAS
console open **Feasibility → Import Gate 0A report**, choose `report.json`, and
select **Validate & import report**. The API accepts only the
`cas-gate0a-report-v2` contract, requires the expected Pixel/API/ADB/package
identity and safety flags, and records every import as INCONCLUSIVE.

Review checklist:

1. The evidence class is `physical-device-observation` for a managed Pixel, or
   `simulated-emulator` for the pinned emulator rehearsal. Never import a
   sample or emulator report as physical evidence.
2. Preflight is `PASS`; resolve any `BLOCKED` or document every `WARN` before
   continuing. Confirm serial, model, Android version/build, USB state, and
   disposable package identity.
3. Check the run status, per-check outcomes, timestamps, unresolved warnings,
   and raw evidence references. Keep the complete run directory with the CAS
   field record; do not upload it to a third-party service.
4. Record the operator's physical Gate 0A observation separately. An imported
   report never creates a Pass or GO decision.

## Pinned emulator rehearsal

The approved emulator contract is deliberately separate from the managed
physical run:

| Setting | Pinned value |
| --- | --- |
| AVD name | `CAS_Pixel_8a_API_35` (the numeric suffix tracks the API level) |
| Device profile | `pixel_8a` |
| Android image | `system-images;android-35;google_apis;x86_64` (tracks `tool-requirements.json`) |
| API level | 35 (tracks `androidSdk.apiLevel` in `tool-requirements.json`) |
| Architecture | x86_64 |
| Repeatability settings | animation scales `0`; `stay_on_while_plugged_in=3` |
| Evidence label | `simulated-emulator` |

The API 35 pin is not a hardcoded copy: `scripts/pixel-emulator.ps1` derives
the API level, the AVD-name suffix, and the system image from
`tool-requirements.json`, so the pinned contract moves when the declared SDK
platform moves (and a stale AVD from an earlier platform fails validation
until `-Action create` rebuilds it).

From the copied Windows test kit, the single lifecycle entry point is:

```powershell
scripts\run-pixel-emulator.cmd -Action start
```

`start` creates the pinned AVD when it does not exist, then reuses it for each
rehearsal. The command waits for boot, verifies API 35, x86_64, the QEMU
marker, the pinned AVD identity, the required settings, and a write/read/remove check under
`/data/local/tmp`. It writes labeled JSON and Markdown records to
`emulator-results`.

Available lifecycle actions are:

```powershell
scripts\run-pixel-emulator.cmd -Action create
scripts\run-pixel-emulator.cmd -Action start
scripts\run-pixel-emulator.cmd -Action wait
scripts\run-pixel-emulator.cmd -Action status
scripts\run-pixel-emulator.cmd -Action reset
scripts\run-pixel-emulator.cmd -Action stop
```

`reset` stops only the pinned emulator, starts it with `-wipe-data`, reapplies
the repeatability settings, and reruns every validation check. It never
selects a physical ADB serial. `status` and `wait` are validation-only; they
do not change emulator settings. If the Android system image is missing,
prepare it through the explicitly approved `-PrepareSdk` preflight path before
creating the AVD.

Emulator records are simulation evidence. They are useful for proxy-to-cover
launch, task transitions, local journal behavior, cold/warm/reboot sequencing,
and software regressions. They are not proof of carrier SMS, GPS, SystemUI,
physical lock-screen behavior, managed Device Owner state, launcher behavior on
the field Pixel, or production readiness. Keep the emulator JSON/Markdown
record with the host timing log and mark the run as simulated when importing
or reviewing it.

## CI: SMS send/receipt flow on the emulator

The `sms-receipt-flow-test` job in
`.github/workflows/android-test-package-build.yml` proves the device-direct
delivery path end-to-end before each release: it starts a throwaway dev API
(PostgreSQL + `CAS_SMS_DELIVERY_MODE=device`) on the runner, boots the
emulator, and runs `.github/scripts/verify-sms-flow.sh`, which:

1. Preflights the handset-facing contracts over plain HTTP: `device-pending`
   and both receipt endpoints must refuse a missing device token (401) and a
   malformed body (400), and `device-pending` must return an `items` array.
2. Drives the app headlessly through `SmsFlowActivity` — a debug-source-set
   activity with `android:exported="false"`, so other apps (and on API 35,
   the plain adb shell user) cannot start it; the harness elevates with
   `adb root` first, which needs a rootable image like the CI emulator. It
   accepts caller-controlled responder numbers and can reuse the stored
   device credential, so it must never be exported or shipped in a release
   build. The handset's radio failure receipt must move the console's outbox
   item QUEUED → DEAD_LETTER.
3. Re-queues the item through the console endpoint, then drives the
   `requeue` mode with a fixed number; the handset picks it up from
   `device-pending`, re-sends, and the receipt must move the item → SENT.
4. Asserts the on-device journal shows the receipts were actually POSTed
   (`SMS_RECEIPT_OUTCOME … REPORTED`) and that nothing crashed.

`SmsFlowActivity` accepts `mode` (`alert`/`requeue`), `serverUrl`,
`deviceToken`, and `responders` extras and persists them to `TestStore` before
running, so the harness can swap the responder list between phases without UI
taps. The harness tunnels the runner's dev API into the device with
`adb reverse tcp:<port> tcp:<port>`, so the app talks to
`http://127.0.0.1:<port>` — the same mechanism works on an emulator and on a
USB-attached field device, and unlike the qemu `10.0.2.2` host alias it does
not depend on the host's network namespace. Plain HTTP is allowed only for
these loopback endpoints (`network_security_config.xml`, and `AlertSender`
accepts exactly those hosts); every real destination stays HTTPS-only.

Any drift in the `sms-receipt`/`device-receipt` or `device-pending` contracts
fails the job loudly: the preflight rejects the drifted response, or the
outbox state never reaches the expected state within the polling budget.

A note on running the harness outside CI: it only needs an ADB-attached device
whose radio can actually send SMS. Sandboxed/containerized hosts whose
emulated cellular modem never registers (no SIM, `isms`/`phone` services
absent, `SmsManager` throwing `UnsupportedOperationException: Sms is not
supported` for every send) cannot complete the SENT leg — the harness fails
there loudly, as designed. Use CI or a workstation whose emulator has a
working fake modem for the full pass.

## Windows workstation preflight

Use the Windows entry point before building or running the disposable package.
It is designed for an operator who should not have to guess which tools or
environment variables are missing:

1. Copy this `android-test-package` directory to the approved Windows test
   workstation.
2. Double-click `scripts/run-windows-preflight.cmd`.
3. Leave the default target as `physical` for the managed Pixel field run.
   Use `scripts/run-windows-preflight.cmd -Target emulator` only when the
   approved emulator is the intended target. `-Target both` checks both paths.
4. Review the plain-language `PASS`, `WARN`, and `BLOCKED` lines. For an
   emulator rehearsal, create/start the pinned AVD with
   `scripts\run-pixel-emulator.cmd -Action start` after the preflight passes.
5. Attach the matching JSON and Markdown files written to `preflight-results`
   to the CAS field-run record. Do not continue a Gate 0A run with a
   `BLOCKED` result.

The command file only starts the PowerShell preflight. The default preflight is
read-only: it checks local tools and reads `adb devices -l`, but it does not
install an APK, change Device Owner state, reboot a device, send a message, or
capture evidence. It returns exit code `0` for `PASS`, `1` for `WARN`, and `2`
for `BLOCKED`.

If the official Android SDK Command-line Tools are already installed, an
operator may explicitly prepare the SDK packages with:

```powershell
scripts\run-windows-preflight.cmd -Target physical -PrepareSdk
```

The script prints the package list and waits for the operator to type
`INSTALL`. Nothing is installed if that confirmation is not provided. The
optional preparation only covers `platform-tools` plus the SDK platform and
build-tools packages declared in `tool-requirements.json`; emulator mode also
includes the official `emulator` package and the pinned
`system-images;android-<apiLevel>;google_apis;x86_64` package matching the SDK
platform declared in `tool-requirements.json`.
It never installs an APK or changes the device.

### Local preflight contract

The workstation must satisfy these checks before the native Gate 0A package is
built or measured:

| Area | Required result |
| --- | --- |
| Java | A JDK at or above the minimum major version declared in `tool-requirements.json`; `JAVA_HOME` points to the JDK root and `JAVA_HOME\bin` is on `PATH` |
| Android SDK | `ANDROID_SDK_ROOT` or `ANDROID_HOME` points to an existing SDK; if both are set, they point to the same folder |
| Platform tools | `platform-tools\adb.exe` exists and `platform-tools` is on `PATH`; `adb version` succeeds |
| Android platform | The `platforms\android-<apiLevel>\android.jar` declared in `tool-requirements.json` exists |
| Build tools | An Android Build-Tools release at or above the minimum declared in `tool-requirements.json` exists |
| Gradle | The Gradle release declared in `gradle-version.txt` is available on `PATH` (this matches the Android Gradle Plugin 8.7.3 used by the package); a different major.minor warns because CI only exercises the declared release. A missing or invalid `gradle-version.txt` blocks the preflight outright — the kit carries no fallback release, so restore the complete, unmodified test kit |
| Physical target | An approved physical device appears as `device` in `adb devices -l`; `unauthorized` and `offline` are blocking states |
| Emulator target | `emulator\emulator.exe` exists; use the pinned lifecycle command to create/start and validate the emulator |

The result JSON uses schema `cas-windows-preflight-v1`. It contains the target
mode, host and tool observations, every check, next steps, the overall status,
and a safety record showing that no device action was performed. Later Gate 0A
commands can include the JSON alongside the in-app report and host timing log.

### Recovery paths

- **Missing SDK platform or build tools:** In Android Studio, open
  **Tools > SDK Manager**, select the Android SDK Platform and Build-Tools
  releases declared in `tool-requirements.json`, plus Android SDK
  Platform-Tools, then apply the change with the operator's approval.
  Alternatively, use the script's `-PrepareSdk` path after installing the
  official command-line tools.
- **`JAVA_HOME` or `ANDROID_SDK_ROOT` is missing:** Set the variable to the
  installation folder, not its `bin` or `platform-tools` child folder. If both
  `ANDROID_SDK_ROOT` and `ANDROID_HOME` are present, make them identical or
  clear the obsolete one. Close and reopen the command window after changing
  variables.
- **PATH issues:** Add the JDK `bin` folder, the SDK `platform-tools` folder,
  and the Gradle `bin` folder to the user or approved workstation `PATH`.
  Re-run the preflight from a new window; an old window keeps the old PATH.
- **ADB says `unauthorized`:** Unlock the approved device and accept the RSA
  debugging prompt on the device. If the prompt is missing, use the device's
  Developer options to revoke USB debugging authorizations, reconnect the
  cable, and accept the new prompt. The preflight does not clear authorizations
  or change Device Owner state.
- **ADB says `offline` or no device is listed:** Check the USB cable, Windows
  Device Manager, the selected USB mode, and whether USB debugging is enabled.
  For an emulator, run `scripts\run-pixel-emulator.cmd -Action start` and
  review its API, architecture, boot, settings, and writable-state checks. Do
  not treat a missing device or a passing emulator check as a physical Gate 0A
  pass.
- **Windows permission or antivirus blocks a tool:** Use an approved,
  administrator-reviewed installation location and allow the signed Android
  and Java tools through the organization's policy. Do not work around
  Windows security by downloading replacement binaries or disabling protection.
- **Gradle cannot run or warns about a version mismatch:** Confirm the `gradle`
  executable on PATH matches the release declared in `gradle-version.txt` and
  that Java points to the same JDK installation that satisfies
  `tool-requirements.json`. The package has no
  checked-in Gradle wrapper, so the workstation's approved Gradle installation
  is intentional; `gradle-version.txt` keeps it aligned with the release CI
  builds with.

The preflight does not provision Device Owner mode, install or uninstall an
APK, factory-reset a device, send SMS/XMPP, or collect evidence. Those actions,
if ever approved for a later experiment, require a separate explicit procedure
and confirmation.

For a managed-device experiment, provision the package as device owner using
the workstation's approved test-device procedure. The app does not silently
change device-owner state.

## Gate 0A run

1. Open **CAS Pixel Gate 0A** and enter the installed cover package name.
2. Save the cover app and request the pinned proxy shortcut. The launcher owns
   the final pin confirmation.
3. Run the proxy from the shortcut for cold, warm, locked, after reboot, and
   repeat-launch samples (the handoff calls for at least 200 repeats).
4. Exercise Back/Home/Recents, Settings > App info, notifications, and
   Quick Settings with an ordinary observer.
5. Copy the JSON report after each run. It includes wall-clock and elapsed
   trigger timestamps, cover launch outcomes, boot observations, task and
   Recents artifacts, Back observations, permission state, device-owner state,
   shortcut state, and explicit observer review items.

`NOT_LAUNCHED` is a recorded result when the cover package is missing or has no
launcher intent. A failed cover launch never performs any other action.

For a software rehearsal, start the pinned emulator first and run the same
proxy flow. The host log begins with the emulator serial, AVD, API, ABI,
fingerprint, image, and the `simulated-emulator` evidence label. Attach the
matching `emulator-results` JSON/Markdown record as well. Do not import or
describe emulator output as physical evidence.

## Measurement notes

The package records trigger time immediately before forwarding and stores both
`wallClockMs` and `elapsedRealtimeMs`, allowing cold/warm/locked/reboot
comparisons on the device. It does not claim a pass automatically: the
operator must record the physical result in the CAS console's Gate 0A
observation and document any abnormal transition, extra splash/frame, wrong
task, broken Back behavior, or stray Recents card.

The measurement script detects the QEMU marker and writes
`evidenceClass=simulated-emulator` plus image metadata when it is run against
the pinned AVD. This is a software rehearsal log, not a replacement for the
managed Pixel run.