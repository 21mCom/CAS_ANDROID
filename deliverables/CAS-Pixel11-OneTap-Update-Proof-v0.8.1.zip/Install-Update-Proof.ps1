#Requires -Version 5.1
<#
.SYNOPSIS
  Runner for the one-tap self-update field proof (CAS Pixel 11).

  Steps:
    InstallN       uninstall any old-key install, then install build N
                   (app-v7-release-signed.apk, versionCode 7).
    CrossKey       attempt to install app-v8-crosskey.apk (same versionCode 8,
                   signed with the DEFAULT ANDROID DEBUG KEY) over the field
                   install. Android must REFUSE it — that refusal is the proof
                   that a wrong-key (or tampered-and-resigned) update cannot
                   replace the field app.
    CaptureJournal pull the app's debug journal and list every UPDATE_* event
                   in order — paste the output into the report template.

  Run from an elevated-or-normal PowerShell window with adb on PATH and the
  Pixel connected + USB-authorized. The script resolves its own folder, so it
  works from anywhere:
    powershell -ExecutionPolicy Bypass -File .\Install-Update-Proof.ps1 -Step InstallN
#>
param(
  [Parameter(Mandatory = $true)]
  [ValidateSet('InstallN', 'CrossKey', 'CaptureJournal')]
  [string]$Step
)
$ErrorActionPreference = 'Stop'

# Resolve script-relative paths AFTER parameter binding (5.1 evaluates default
# parameter values before the body runs).
$pkg  = 'com.covertalert.pixeltest'
$apkN = Join-Path $PSScriptRoot 'app-v7-release-signed.apk'
$apkX = Join-Path $PSScriptRoot 'app-v8-crosskey.apk'

if (-not (Get-Command adb -ErrorAction SilentlyContinue)) {
  Write-Host "ERROR: adb is not on PATH. Install Android platform-tools, then re-open PowerShell."
  exit 1
}

# Native stderr under $ErrorActionPreference='Stop' turns merged 2>&1 output
# into a terminating error on Windows PowerShell 5.1 — drop to Continue around
# adb calls and check output text + $LASTEXITCODE instead.
function Invoke-Adb {
  param([string[]]$AdbArgs)
  $prev = $ErrorActionPreference
  $ErrorActionPreference = 'Continue'
  $text = (& adb @AdbArgs 2>&1 | Out-String)
  $code = $LASTEXITCODE
  $ErrorActionPreference = $prev
  return @{ Text = $text; Code = $code }
}

switch ($Step) {
  'InstallN' {
    if (-not (Test-Path $apkN)) { Write-Host "ERROR: $apkN not found next to this script."; exit 1 }
    Write-Host "== InstallN: removing any previous install (old debug key) =="
    $u = Invoke-Adb @('uninstall', $pkg)
    Write-Host $u.Text
    Write-Host "== InstallN: installing build N (versionCode 7, field release key) =="
    $i = Invoke-Adb @('install', $apkN)
    Write-Host $i.Text
    if ($i.Text -notmatch '(?m)^Success') {
      Write-Host "ERROR: install of build N did not report Success (see output above)."
      exit 1
    }
    Write-Host "OK: build N installed. Continue in the run guide (step 3: open app, save alert server, enroll)."
    exit 0
  }
  'CrossKey' {
    if (-not (Test-Path $apkX)) { Write-Host "ERROR: $apkX not found next to this script."; exit 1 }
    Write-Host "== CrossKey: attempting to install the debug-key-signed v8 APK over the field install =="
    $i = Invoke-Adb @('install', '-r', $apkX)
    Write-Host $i.Text
    if ($i.Text -match 'INSTALL_FAILED_UPDATE_INCOMPATIBLE|INSTALL_FAILED_UPDATE_WRONG_KEY|INSTALL_PARSE_FAILED_INCONSISTENT_CERTIFICATES|signatures do not match|INSTALL_FAILED_VERSION_DOWNGRADE') {
      Write-Host "PROOF OK: Android refused the cross-key update package. The field install is untouched."
      exit 0
    }
    if ($i.Text -match '(?m)^Success') {
      Write-Host "ERROR: the cross-key package INSTALLED — Android's same-signing-key enforcement did not fire. Stop and report this."
      exit 1
    }
    Write-Host "ERROR: unexpected adb result — neither a known refusal nor Success (see output above)."
    exit 1
  }
  'CaptureJournal' {
    Write-Host "== CaptureJournal: pulling UPDATE_* events from the app's debug journal =="
    $j = Invoke-Adb @('shell', "run-as $pkg cat /data/user_de/0/$pkg/shared_prefs/gate0a-local-journal.xml")
    if ($j.Code -ne 0 -or [string]::IsNullOrWhiteSpace($j.Text)) {
      Write-Host "ERROR: journal unreadable (is the app installed and was it opened at least once?). Raw output:"
      Write-Host $j.Text
      exit 1
    }
    # shared_prefs XML entity-escapes the JSON payload (&quot; &amp; &lt;
    # &gt; &apos;), so decode before matching or every quote-anchored pattern
    # silently finds zero events on a healthy phone.
    $journal = [System.Net.WebUtility]::HtmlDecode($j.Text)
    # The journal stores its events as a JSON array; each object carries its
    # event family in the "type" key (see TestStore.record).
    $matches = [regex]::Matches($journal, '\{[^{}]*"type"\s*:\s*"UPDATE_[A-Z_]+"[^{}]*\}')
    if ($matches.Count -eq 0) {
      Write-Host "No UPDATE_* events found in the journal. Open the app once so the update check runs, then retry."
      exit 1
    }
    foreach ($m in $matches) { Write-Host $m.Value }
    Write-Host "== $($matches.Count) UPDATE_* event(s). Paste everything between the == lines into the report template. =="
    exit 0
  }
}
