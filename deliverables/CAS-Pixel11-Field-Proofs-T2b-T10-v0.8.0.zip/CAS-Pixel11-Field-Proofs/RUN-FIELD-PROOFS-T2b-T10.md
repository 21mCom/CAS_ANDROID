# CAS Pixel 11 — Field proofs run sheet (T2b location accuracy + T10 evidence capture)

One session on the Windows hardware workstation with the Pixel 11 attached.
This pack proves the two things the emulator cannot: real-world GPS accuracy in
the alert path (T2b) and real evidence capture landing in the console (T10),
with T10b push-wake as an optional extra.

Everything runs as a standard Windows user. No administrator rights are needed.

## What you need before starting

- The Windows workstation that passed the Gate 0A / MVP preflight, with the
  Pixel 11 (API 35 or newer) and its USB-C data cable.
- A responder phone that can receive SMS (for T2b you compare its received
  message against the Pixel's true position).
- The **server URL**, **device access token**, and **alert credential** from
  the accompanying message. They are secrets and are deliberately NOT in this
  ZIP. Never paste them into the report-back, chat, or email.
- An outdoor spot with sky view and an indoor spot deep inside a building,
  plus a ~100 m walking stretch outdoors for the movement re-capture proof.
- About 60–75 minutes.

The full drill reference is `android-test-package\HANDOFF-TEST-KIT.md` — this
sheet sequences the steps you need and adds the report-back template. If any
step's wording disagrees with the kit doc, the kit doc wins; note the
disagreement under Blockers/questions.

## Step 0 — Extract and preflight (T0)

1. Extract this ZIP to a writable folder, e.g. `Desktop\CAS-Pixel11-Field-Proofs`.
   Do not run scripts from inside the ZIP preview window.
2. (Optional integrity check) In the extracted folder run
   `certutil -hashfile <file> SHA256` on any file you doubt, or on Git Bash /
   WSL `sha256sum -c SHA256SUMS.txt` to verify every file at once.
3. `android-test-package\scripts\run-windows-preflight.cmd` → expect `PASS`.
4. In PowerShell, from `android-test-package`:

   ```powershell
   . .\scripts\cas-api-drills.ps1 -BaseUrl https://<server-host> -DeviceToken <device-access-token> -AlertToken <alert-credential>
   Get-CasOutboxStatus
   ```

   Pass: `smsDeliveryMode` is `device`, `deviceChannels` contains `SMS` only,
   `deviceAuthConfigured` is true, worker heartbeat `running` is true.
5. Open the console in a browser and confirm the **Evidence capture** page
   exists. If it does not, the server is running an older build — stop and
   report back; T10 cannot pass against it.

## Step 1 — Install the app (T1)

`android-test-package\scripts\run-mvp-install.cmd` → type `INSTALL MVP` when
prompted. Pass: `adb shell dumpsys package com.covertalert.pixeltest | findstr versionName`
prints `0.8.0-selfupdate`.

This pack ships the push-less build (no `google-services.json`): responder
capture requests are honored on the phone's next server contact (polling).
That is the expected configuration for this run — see Step 4.

## Step 2 — Baseline alert (T2)

On the phone: save the alert server URL, device access token, and alert
credential; save responder number(s); grant SMS and location permissions.
Send one alert. Pass: responder receives the SMS ending in a
`maps.google.com` link with `(±Nm, fix Xs old)`, the console incident shows
the same fix, and the SMS outbox item turns `SENT`. Resolve the incident.

This first provisioned alert also enrolls the phone's per-device credential —
evidence upload in Step 3 depends on it, so do not skip Step 2.

## Step 3 — T2b location accuracy proof (outdoors + indoors)

1. **Outdoors** (sky visible): send an MVP alert. Drop a pin in a maps app at
   the phone's true position and compare it with the SMS map link. Pass: the
   link lands within the stated accuracy radius (`±Nm`) of the true position,
   and the fix age is small (`fix Xs old`, not minutes). Record the accuracy
   radius, fix age, and incident id. Resolve the incident.
2. **Indoors** (deep inside a building): repeat. Pass: the alert still leaves
   within the bounded wait (~8 s worst case) and either carries a coarser fix
   honestly labeled with a larger `±Nm` radius / a `+last-known` age, or says
   `no fix captured for this alert.` — it must not present a stale fix as
   current and must not wait indefinitely. Record exactly which behavior you
   saw, with the radius/age wording. Resolve the incident.
3. **Airplane-mode toggle (optional):** turn location off at the OS level and
   send once more. Pass: the alert leaves immediately and both the SMS and the
   console say no fix was captured. Re-enable location afterwards.
4. **Movement re-capture** (outdoors, incident still ACTIVE): keep the app
   open after the send and walk at least 100 m (a short block is enough);
   wait up to ~1 minute at the far point. Pass: the console incident journal
   gains a `LOCATION_UPDATED` entry per accepted fix (`Movement re-capture
   fix #N …` with accuracy `±Nm` and capture age), the incident's location
   panel moves to the newest fix, and the phone's debug journal shows
   `LOCATION_RECAPTURE_STARTED` then `LOCATION_RECAPTURE_FIX` with
   `outcome=POSTED_MOVEMENT`. Fixes arrive at most once a minute however far
   you walk; standing still still re-baselines every 5 minutes
   (`POSTED_PERIODIC`). Record the incident id and the outcomes seen.
5. **Stop on resolve**: resolve the incident in the console, then walk
   another 100+ m. Pass: no new `LOCATION_UPDATED` entries appear; within
   one movement (or one 5-minute periodic cycle) the phone's debug journal
   shows `LOCATION_RECAPTURE_STOPPED` with reason `incident no longer
   active on the server`. The watch never runs longer than 2 hours per
   incident (`duration cap reached`) even if nobody resolves it.

## Step 4 — T10 evidence capture playground

The green OS mic/camera indicator during capture is expected and accepted.

1. In the console, open **Evidence capture**. Set **Audio** to *Start on
   trigger* and timing to *Immediate*. On the phone: **Grant microphone
   permission**.
2. Send an alert, then immediately lock the phone and set it down. Pass: the
   console incident's evidence panel fills with rolling audio clips
   (`audio · clip 1`, `clip 2`, … up to 6 × 30 s) within a couple of minutes,
   each **Download**-able and playable, and the journal shows
   `EVIDENCE_UPLOADED` per clip. No app UI ever appeared on the phone.
3. Set **Photo** to *Start on trigger*, grant camera permission, alert again.
   Pass: one still photo lands in the panel; the camera app UI never opened
   on the phone.
4. Set **Video** to *Start on trigger*, alert again. Pass: one ~20 s video
   clip lands in the panel, playable after download.
5. **Timing experiment:** switch timing to *On screen-off* and run the same
   scenario twice — once locking the phone right away, once leaving the
   screen on for ~2 minutes first. Pass: in both runs capture begins only
   after the screen turns off. Compare clip content against the immediate
   runs and note which catches more useful evidence.
6. **Responder-requested capture:** set **Audio** to *Only when a responder
   asks*. Trigger an alert (no audio should start). From the console incident
   view, press **Request audio capture**, then on the phone tap **Check
   re-queued deliveries**. Pass: the journal shows
   `CAPTURE_REQUESTED → CAPTURE_STARTED → CAPTURE_COMPLETED` and the clip
   lands in the panel. If Android refused the background start, the journal
   instead shows `CAPTURE_FAILED` with the exact exception — record that
   text; it is the measured background-start limit.
7. Resolve the incident. Note which timing mode caught better evidence and
   how visible each capture start was.

## Step 5 — T10b push wake (optional, SKIP expected)

This pack's build has no Firebase config. On the phone, send one alert and
leave the app once: the on-screen report is expected to show
`PUSH_UNAVAILABLE`. Record T10b as SKIP (push build not provisioned) unless
the accompanying message says the server has `CAS_FCM_SERVICE_ACCOUNT_*`
configured AND you placed `google-services.json` at
`android-test-package\app\google-services.json` before Step 1 — in that case
run the full T10b drill from the kit doc.

## Step 6 — Report back

Fill in `REPORT-BACK-T2b-T10.txt` and paste it into the workspace chat, plus
the exact wording of any failing SMS location sentence, any `CAPTURE_FAILED`
exception text, and any failing command output. Do not include any token
values.
