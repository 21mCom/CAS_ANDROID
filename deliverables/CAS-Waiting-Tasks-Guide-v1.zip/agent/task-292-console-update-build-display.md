# Agent handoff — unblocks task #292

# Show which update build the server is shipping in the console

Actor: workspace agent. No operator action needed.

## Goal

Operators publish update builds with one curl (enrollment credential) and
handsets poll the manifest — but the console UI never shows which build is
currently published, its SHA-256 pin, or when it was uploaded. An operator
verifying "what will phones install right now?" has no UI answer. Add a small
read-only section (e.g. on the settings/readiness surface) backed by
`GET /api/cas/app-updates/manifest` (already credentialed; 404 = nothing
published).

## Done looks like

- The console shows the published build's versionName/versionCode, size,
  SHA-256, and publish time — or a clear "no build published" state.
- Console reads keep the existing enrolled-credential posture (no anonymous
  reads; the console's read posture was deliberately retired from anonymous —
  see `.agents/memory/cas-console-read-posture.md`).
- Follow the credential-gated fetch pattern used by the existing console
  pages, including the load-failure routing (mismatch / credential-lock /
  labeled-offline-demo — a cancelled prompt must never show the demo seed;
  see `.agents/memory/cas-console-load-failure-routing.md`).

## References

- `artifacts/api-server/src/routes/cas-updates.ts` (manifest endpoint)
- `artifacts/covert-alert-system/src/pages/` (console pages; copy the
  credential-gated fetch pattern from an existing page)
