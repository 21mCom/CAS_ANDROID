# Agent handoff — unblocks task #224

# Run the silently-reverted-work sweep in GitHub CI once history pushes are unblocked

Actor: workspace agent. Prerequisite: task #234 complete (normal pushes to
GitHub main work again). This task is blocked on that parent — do not start
it before.

## Goal

The stale-snapshot merge-clobber pattern has struck main committed, not just
mid-task. The sweep `scripts/check-merge-clobber.mjs` already runs post-merge
in the workspace; add a GitHub Actions job so a clobbered push is caught even
when no workspace merge follows.

## Done looks like

- A CI job runs `node scripts/check-merge-clobber.mjs` on pushes/PRs to main
  with a `fetch-depth: 0` checkout, and fails on unexcluded findings.
- Deliberate break/revert proof commits in CI-only branches carry
  `[no-clobber-check]` or an allowlist entry, so the job stays actionable
  (red only for real clobbers).

## Constraints

- Pushes/dispatches use the GITHUB_PAT secret (connector is read-only).
- Follow the existing path-trigger pattern in `.github/workflows/`.

## References

- `scripts/check-merge-clobber.mjs`
- `scripts/merge-clobber-allowlist.json`
- `.github/workflows/api-server-tests.yml` (pattern for path triggers)
