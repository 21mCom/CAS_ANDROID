# Agent handoff — unblocks task #291

# Confirm the update-safety harness passes on its first real GitHub CI run

Actor: workspace agent. No operator action needed.

## Goal

`.github/workflows/android-test-package-build.yml` has an update-check job
running `scripts/test-update-check.sh` (pinned-kotlinc JVM harness for the
self-update channel's pins: strict manifest parse, versionCode-only
newer-wins, size + SHA-256 verification before install handoff). It passes
locally (UPDATE_CHECK_OK checks=21) but has never run on real GitHub CI.
Confirm its first real run there.

## Done looks like

- The update-check job runs on GitHub Actions against a branch containing
  these changes and finishes green.
- The job log is kept as evidence.

## Constraints

- FIRST-RUN SCAN: before dispatching, scan existing workflow run logs for the
  job's marker — a concurrent push may already have been the first run.
- Pushes/dispatches use the GITHUB_PAT secret (connector is read-only); a
  branch push touching the android-test-package paths triggers the workflow.
- Local replay is pre-validation only — never mark this complete on a local
  simulation.

## References

- `.github/workflows/android-test-package-build.yml` (update-check job)
- `scripts/test-update-check.sh`
- `scripts/update-check/UpdateCheckHarness.kt`
- `.agents/memory/github-ci-access.md`, `.agents/memory/ci-first-run-scan.md`
