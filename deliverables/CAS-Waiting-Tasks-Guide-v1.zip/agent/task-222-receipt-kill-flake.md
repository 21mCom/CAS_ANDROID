# Agent handoff — unblocks task #222

# Stop the killed-phone receipt drill from flaking when a slow emulator delays the force-stop

Actor: workspace agent. No operator action needed.

## Goal

`.github/scripts/verify-receipt-durability-kill.sh` scenario A flaked once on
this workspace's TCG emulator: the proxy's `.seen` marker fired, but the 10s
client read timeout expired and journaled the FAILED receipt outcome before
the harness's force-stop landed (adb/am latency on a slow TCG boot). A retry
passed — a timing flake, not a logic bug — but on a slow CI emulator it can
fail a valid run.

## Done looks like

- Scenario A's marker-to-force-stop path is robust to slow adb round-trips —
  e.g. pre-arm the force-stop, widen the proxy hang window beyond the client's
  read timeout, or retry the in-flight attempt when the journal proves the
  kill was late rather than the durability broken.
- The drill still fails loudly when the receipt genuinely beats the kill for
  real reasons.
- A full harness run passes on a booted emulator (HARNESS_EXIT=0).

## Constraints

- The workspace's TCG emulator can boot and run this harness locally
  (see `.agents/memory/android-emulator-in-workspace.md`); use adb reverse,
  not 10.0.2.2.
- Emulator jobs on GitHub CI only boot on ubuntu + KVM + x86_64; runner script
  blocks run under dash — no pipefail, single-line bash invocation
  (`.agents/memory/android-emulator-ci.md`).
- Related known flake, do not conflate: adb root after an emulator reboot
  needs a bounded retry (`.agents/memory/ci-adbd-post-reboot-flake.md`).

## References

- `.github/scripts/verify-receipt-durability-kill.sh` (scenario A,
  wait_proxy_seen / force-stop sequencing)
- `.github/scripts/cas-receipt-gate-proxy.py` (hang-flag mechanics)
