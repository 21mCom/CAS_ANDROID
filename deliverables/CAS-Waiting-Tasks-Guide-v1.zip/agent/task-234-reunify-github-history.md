# Agent handoff — unblocks task #234

# Re-unify GitHub main with the workspace history so normal pushes work again

Actor: workspace agent. Prerequisite: the operator's go-ahead (human Part 1
of START-HERE.md). Task #224 depends on this one finishing.

## Goal

Workspace `main` and GitHub `main` diverge by dozens of commits both ways
(remote carries concurrent-session commits stacked on the pre-unification
lineage 83366d2/8fe01c2; the workspace tip has 40+ commits the remote
lacks). Merge or rebase them back to one shared tip so a normal
`git fetch` + `git push` works again.

## Constraints (from the task plan and project memory — all mandatory)

- Coordinate before integrating: check `/actions/runs` and recent remote
  commits so no concurrent session is mid-push. Multiple sessions push from
  this workspace; fetch + rebase onto FETCH_HEAD immediately before pushing
  and expect non-fast-forward rejections.
- Review EVERY "-" line of any reconciliation diff in full before accepting
  it — the 83366d2 sync clobbered the remote lineage's arm64-v8a fix
  because the "superset" verdict rested on a truncated sample.
- Re-run the FULL test suite post-integration; a completion rebase has
  mangled mainline before (recover via reflog pre-rebase tip if needed).
- Do NOT merge FETCH_HEAD into the shared workspace mid-session if live
  concurrent work is present — prefer the scratch-clone technique
  (`git clone --depth 50` to /tmp, edit, commit, push fast-forward).
- Push auth: GITHUB_PAT via explicit credentialed URL with
  `GIT_ASKPASS= GIT_TERMINAL_PROMPT=0` (Basic http.extraHeader works;
  Bearer does not — Bearer is for the Actions REST API only). The OAuth
  connector is read-only; `replit-git-askpass` mints invalid tokens.
  PAT expires 2026-12-27.
- If push protection (GH013) rejects the history push: the PAT carries the
  bypass permission —
  `POST /repos/21mCom/CAS_ANDROID/secret-scanning/push-protection-bypasses`
  with `{"reason":"used_in_tests","placeholder_id":"<id from the rejection
  URL>"}`, then re-push immediately. Never write the flagged literal into
  any file.

## Evidence to produce

- Workspace main and GitHub main share one tip.
- A normal `git fetch` + push of a trivial commit succeeds (paste the
  command output).
- Full test-suite result after the integration.

## References

- `.agents/memory/github-ci-access.md` (divergence record, bypass API,
  scratch-clone technique, superset-review lesson)
- `.agents/memory/github-ci-push-auth.md` (push commands)
- `.agents/memory/concurrent-task-merge-clobber.md`
- `.agents/memory/completion-rebase-can-mangle-mainline.md`
