# Agent handoff — unblocks task #217

# Confirm the outbox-status and settings drift checks pass on their first real GitHub CI run

Actor: workspace agent. No operator action needed.

## Goal

The parity test `artifacts/api-server/src/lib/cas-outbox-config-schema.test.ts`
(AST-parses the outbox/status route, the config routes, and the worker/device/
template lib types; compares field-by-field against the console mirror schemas)
passes locally (16 tests green) and is wired into the api-server test:direct
chain, but has never run on real GitHub CI. Confirm its first real run there.

## Done looks like

- A push or workflow trigger runs the api-server-tests workflow on GitHub and
  the job log shows `cas-outbox-config-schema.test.ts` with 16 passes.
- Keep the job log as evidence.

## Constraints

- FIRST-RUN SCAN: before dispatching anything, scan existing workflow run logs
  for the phase marker — a concurrent push may already have been the first
  run. Do not burn a duplicate CI run.
- Pushes/dispatches use the GITHUB_PAT secret (connector is read-only).
- Watch for a path-resolution difference on GitHub: the test resolves the
  console mirror sources via a relative `../../../covert-alert-system/...`
  path from the api-server tree.
- Local replay is pre-validation only — never mark this complete on a local
  simulation.

## References

- `artifacts/api-server/src/lib/cas-outbox-config-schema.test.ts`
- `artifacts/api-server/package.json` (test:direct chain)
- `.github/workflows/api-server-tests.yml`
- `scripts/run-cas-contract-tests.mjs`
- `.agents/memory/github-ci-access.md`, `.agents/memory/ci-first-run-scan.md`
