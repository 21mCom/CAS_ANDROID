# Sheet 01 — Task #266: Text messages still send when splitting fails

Who does this: you, at the Windows workstation with the Pixel 11.
Time: about 10 minutes.

## Why

On the real Pixel, the Android feature that splits a long text into parts
("divideMessage") failed for every recipient — the phone gave up on every
text while the server thought all was well. The test app now has a backup
plan: when splitting fails, it notes why and sends the message as one
single text instead. That backup has never been tried on the real phone.
This sheet is that try.

## What you need before starting

- The field pack extracted on the workstation and the rebuilt test app
  installed (see START-HERE, Part 2, "one time only"). The app's version
  must read `0.8.0-selfupdate`.
- The phone already set up from the earlier tests: alert server address,
  device access token, and alert credential saved; at least one responder
  number saved; SMS and location permissions granted. If any of these are
  missing, do sheet 05's "baseline alert" steps first.
- The responder phone nearby so you can see the text arrive.
- A browser open at the console (the server address).

## Steps

1. In the console, make sure no incident is still open from earlier testing
   — resolve any active one first. An open incident makes the next tap
   merge into it and skip the text message entirely.
2. On the phone, open the test app (its launcher name is
   **CAS Pixel Gate 0A**).
3. Tap **Send MVP alert now**.
4. Watch the responder phone. The alert text should arrive within seconds,
   from the Pixel's own number.
5. On the Pixel, look at the on-screen report. You are looking for a line
   that starts `SMS_DIVIDE_FALLBACK`, followed by the technical reason the
   split failed (the "exception text").
6. In the console, open the incident and confirm its SMS delivery chip
   turns **SENT**.
7. Resolve the incident in the console before moving on to sheet 02 —
   sheet 02's checks each need a fresh incident.

## Done looks like

- The responder phone received the text (that is the backup plan working).
- The phone's report shows `SMS_DIVIDE_FALLBACK` with the reason text.
- The console shows the SMS item as SENT.

## What to paste back

Copy the matching block of `human/REPORT-BACK-FIELD-SESSION.txt` and fill
it in. The most important part is the exact `SMS_DIVIDE_FALLBACK` reason
text — it tells the developers why Android 17 breaks the splitting feature
and whether a deeper fix is worth doing. If anything failed, also tap
**Copy debug journal** in the app and paste that.
No token values, ever.
