# Sheet 06 — Task #290: The phone updates itself with one tap

Who does this: mostly the agent on the Windows workstation (it builds and
publishes the newer app file); you do the phone taps.
Time: about 30 minutes, most of it the agent's building.

## Why

New test-app builds no longer need a USB cable: the phone checks the server
for a newer build and can download and install it after one tap and one
Android confirmation prompt. The server side is proven by automated tests,
but the install prompt and Android's "same signing key" rule can only be
proven on the real phone. Run this sheet LAST in the session — every other
sheet needs the currently installed build.

## What you need before starting

- Sheets 01–05 done (or deliberately skipped): this sheet replaces the app
  with a newer build at the end.
- The phone set up and enrolled (it has sent at least one alert).
- The Windows workstation agent ready to do the build-and-publish part
  (hand it the "For the workstation agent" section below).

## Steps (your part)

1. Ask the workstation agent to build and publish build N+1 (section
   below). Wait until it says the new build is published.
2. On the phone, open the test app. The **App updates** line under the
   buttons should say a newer build exists and **Download & install
   update** should be tappable.
3. On Wi-Fi: tap it. The download should start straight away. On mobile
   data instead (try this once if you can): the phone asks first and shows
   the download size — that consent prompt is part of the proof.
4. Android shows exactly one system confirmation prompt. Confirm it.
5. Reopen the app. The version line should now show the new build number
   (for example from `0.8.0-selfupdate` to the newer one the agent made).
6. First time only: if Android says the app may not install updates, allow
   it once under Settings → Apps → CAS Pixel Gate 0A → Install unknown
   apps, then tap Download & install again.
7. Safety check (agent's part, you just watch): a tampered or wrongly
   signed app file must be refused — the phone's journal shows an
   UPDATE_DOWNLOAD failure or Android itself rejects the install.

## Done looks like

- The phone went from build N to build N+1 with one tap plus one Android
  prompt — no cable, no computer-side install command.
- The mobile-data consent prompt appeared when downloading over mobile
  data.
- A tampered or cross-signed file was refused.

## What to paste back

Fill in the task #290 block of `human/REPORT-BACK-FIELD-SESSION.txt`:
version before/after, whether the consent prompt appeared on mobile data,
and the phone's journal lines (UPDATE_CHECK, UPDATE_DOWNLOAD,
UPDATE_INSTALL with their outcomes) via **Copy debug journal**.
No token values, ever.

## For the workstation agent (technical)

- Bump `versionCode`/`versionName` in
  `artifacts/covert-alert-system/android-test-package/app/build.gradle.kts`
  (currently versionCode 7 / `0.8.0-selfupdate`), build with the pinned
  release key exactly as the field-build gates require, then publish per
  "Publishing one-tap phone updates" in `artifacts/api-server/SELF-HOSTING.md`
  (one curl with the enrollment credential). The handset-side flow is
  documented under "Updating the app in the field" in
  `artifacts/covert-alert-system/android-test-package/MVP-HANDOFF-WINDOWS.md`.
- Task plan reference: task #290. Server integration tests
  (`artifacts/api-server/src/routes/cas-updates.test.ts`) and the JVM
  harness (`scripts/test-update-check.sh`) already pass; this run supplies
  the hardware evidence only. Android's same-signing-key enforcement is
  part of the proof — do not work around it.
