# Sheet 05 — Task #235: The main field-proofs run (location + evidence)

Who does this: you, at the Windows workstation with the Pixel 11.
Time: about 60–75 minutes.

## Why

This is the headline field run: it proves the two things no pretend phone
can prove — real-world GPS accuracy in the alert path (the kit calls this
T2b) and real evidence capture landing in the console (T10).

## What you need before starting

- The pack `deliverables/CAS-Pixel11-Field-Proofs-T2b-T10-v0.8.0.zip`
  extracted on the workstation, e.g. to `Desktop\CAS-Pixel11-Field-Proofs`.
  (The task list names an older pack, v0.7.0 — out of date; use v0.8.0.)
- The rebuilt test app installed once (START-HERE, Part 2). If you already
  did sheets 01–04, the app is installed — do not reinstall.
- A responder phone, an outdoor spot with sky view, an indoor spot deep in
  a building, and the ~100 m walking stretch from sheet 04.
- The server address and tokens from the separate message. Never type them
  into any report.

## Steps

The pack contains its own full run sheet. Follow it end to end:

1. Open `RUN-FIELD-PROOFS-T2b-T10.md` inside the extracted pack.
2. Work through it from Step 0 (preflight) to Step 6 (report back).
   - Step 1 (install): already done if sheets 01–04 ran — just confirm the
     version reads `0.8.0-selfupdate`.
   - Step 3, movement re-capture part: if you already did sheet 04, copy
     those results into the template instead of walking twice.
   - Step 4, camera-selector part (T10 4a): if you already did sheet 03,
     copy those results instead of re-running it.
   - Step 5 (T10b push wake): SKIP is expected — this pack's build has no
     push messaging. The sheet explains.
3. If any wording in the run sheet disagrees with the kit reference
   (`android-test-package\HANDOFF-TEST-KIT.md` inside the pack), the kit
   reference wins — note the disagreement under Blockers/questions.

## Done looks like

- T2b outdoors: the texted map link lands within the stated accuracy radius
  of where the phone truly was, and the fix age reads in seconds.
- T2b indoors: the alert still leaves within about 8 seconds, with either
  an honestly-labeled coarser fix or the plain "no fix captured" sentence.
- T10: audio, photo, and video clips land in the console's evidence panel
  while the phone's screen is off; the timing experiment and the
  responder-requested capture results are recorded.

## What to paste back

Fill in `REPORT-BACK-T2b-T10.txt` (a blank copy is in this guide's `human/`
folder, and the same file is inside the pack) and paste the whole filled
template into the workspace chat, plus the exact wording of any failing
location sentence and any CAPTURE_FAILED reason text. If a send or a
capture misbehaved, also tap **Copy debug journal** on the phone and paste
that. No token values, ever.
