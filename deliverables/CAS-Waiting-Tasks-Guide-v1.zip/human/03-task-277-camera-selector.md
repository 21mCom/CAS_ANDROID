# Sheet 03 — Task #277: Front/back camera choice records labeled evidence

Who does this: you, at the Windows workstation with the Pixel 11.
Time: about 15 minutes.

## Why

The console's evidence-capture settings now let you pick which camera the
phone uses for photo and video evidence: back, front, or both. Each file is
supposed to land in the console labeled with its lens. This has never run
on a real phone. This sheet proves it — and finds out whether the Pixel 11
can honestly record from both lenses at once (some phones cannot; the app
is built to say so rather than fake it).

Note: this sheet overlaps with sheet 05's evidence-capture run (kit step
T10 4a). Do it once here and copy the same results into both report
templates.

## What you need before starting

- Same as sheet 01: rebuilt app installed (version `0.8.0-selfupdate`),
  phone set up. Camera permission must be granted on the phone (the app
  has a **Grant camera permission** button).
- The phone must have sent at least one alert since being set up — that
  first alert is what enrolls the phone for evidence upload.
- A browser open at the console (the server address).

## Steps

1. In the console, open the **Evidence capture** page. Set **Photo** and
   **Video** to *Start on trigger*, timing *Immediate*, and **Camera for
   photo & video** to *Front and back*.
2. On the phone, send an alert, then lock the phone and set it down.
3. In the console, open the incident's evidence panel. You should get one
   photo and one video clip per lens — four files — each labeled with its
   camera (for example `photo · back camera`, `photo · front camera`).
   Downloaded files should be named like `…-photo-back-1.jpg` and
   `…-photo-front-2.jpg`. Write down what actually landed and how each was
   labeled.
4. If only the back camera's files arrived, that is the phone honestly
   reporting a hardware limit, not a bug: on the phone, tap **Copy debug
   journal** and find the `EVIDENCE_CAPTURE` line with `outcome=DEGRADED`.
   Copy that line into your notes.
5. Resolve the incident in the console (the next send needs a fresh
   incident), then set **Camera for photo & video** to *Front camera*
   alone, send another alert, and confirm only front-labeled files land.
6. Throughout: the phone's screen should stay off and no camera app should
   ever open. The small green camera dot at the top of the screen is
   Android's own indicator — expected and fine.
7. Resolve the incidents in the console when finished.

## Done looks like

- "Front and back" produced one photo and one video per lens, each labeled
  with its camera — or an honest DEGRADED note explaining the limit.
- "Front camera" produced only front-labeled files.
- No camera app ever opened on the phone.

## What to paste back

Fill in the task #277 block of `human/REPORT-BACK-FIELD-SESSION.txt`,
including any DEGRADED journal line. The same results also go onto the T10
camera line of sheet 05's template (`human/REPORT-BACK-T2b-T10.txt`).
No token values, ever.
