# Sheet 02 — Task #272: The one-line status shows the final answer

Who does this: you, at the Windows workstation with the Pixel 11.
Time: about 15 minutes.

## Why

Under the **Send MVP alert now** button there is a single status line. It
exists so someone sending an alert in a panic does not have to read the
technical report: it should end on DELIVERED when every responder's text
goes through, or SMS_FAILED with a named reason when the phone's radio
reports a problem. It has only been proven in automated tests so far — this
sheet proves it on the real phone, including the failure case.

## What you need before starting

- Same as sheet 01: rebuilt app installed (version `0.8.0-selfupdate`),
  phone set up, responder phone nearby.
- A browser open at the console (the server address). You will change one
  setting there and change it back.

## Golden rule for this sheet

Every step below needs its own fresh incident. Before each send, check the
console and resolve any incident still open from the step before. If an
incident is open, the tap merges into it, no new text goes out, and the
status line cannot show the result this sheet is checking.

## Steps

1. **Happy path.** Make sure the console's **Responders** page lists the
   correct responder number. On the phone, tap **Send MVP alert now** and
   watch the status line under the button until it stops changing (a few
   seconds). Write down exactly what it ends on — you want the word
   DELIVERED and the responder count. Then resolve the incident in the
   console.
2. **Failure path.** In the console's **Responders** page, change the
   responder's number to a deliberately wrong one: just `1`. Save it. (The
   console's list is the one that counts — the phone's own number list is
   only a fallback for when the phone cannot reach the server, so the
   change must be made in the console.) Send an alert from the phone and
   watch the status line. It should end on SMS_FAILED with a named reason —
   the exact name is whatever the phone's radio reports, so do not expect a
   specific word; a destination or no-service style error name is the pass.
   Write down the exact wording. Then change the number back to the correct
   one in the console, save, and resolve the incident.
3. **Background and resume.** Send one more alert and immediately press
   the phone's home button so the app goes to the background. Wait about 15
   seconds, then reopen the app. The status line should already show the
   final answer (DELIVERED) — it catches up when the app comes back.
   Resolve the incident in the console.

## Done looks like

- Step 1 ended with the line reading DELIVERED with the responder count.
- Step 2 ended with SMS_FAILED naming the radio's error, on the line
  itself — reached by breaking the number in the console, then restored.
- Step 3 showed the final outcome after reopening the app.

## What to paste back

Fill in the task #272 block of `human/REPORT-BACK-FIELD-SESSION.txt`: the
exact status-line wording for all three steps. If any step misbehaved, tap
**Copy debug journal** in the app and paste that text as well.
No token values, ever.
