# Sheet 04 — Task #274: Location updates while walking, stop on resolve

Who does this: you, at the Windows workstation with the Pixel 11, plus a
short walk outdoors.
Time: about 20 minutes.

## Why

While an incident is active, the phone is supposed to notice when it has
moved more than about 100 m and send a fresh location fix to the console —
and to stop the moment the incident is resolved. The rules are proven in
automated tests, but the real walking behavior has never run on the real
phone. This sheet is that run. (This is the same thing as steps 4–5 of the
kit's T2b section, so the results also fill rows of sheet 05's template.)

## What you need before starting

- Same as sheet 01: rebuilt app installed (version `0.8.0-selfupdate`),
  phone set up, location permission granted.
- An outdoor walking stretch of at least 100 m (a short block is enough).
- A browser open at the console, with no incident still open from earlier
  sheets — resolve any active one first, or this send merges into it.

## Steps

1. Outdoors, on the phone: send an alert. Leave the app open.
2. Walk at least 100 m. At the far end, wait up to about a minute.
   (Updates arrive at most once a minute however far you walk; standing
   still re-baselines every 5 minutes.)
3. In the console, open the incident and look at its journal. You should
   see new LOCATION_UPDATED entries — one per accepted fix — worded like
   "Movement re-capture fix #1" with an accuracy (±Nm) and an age. The
   incident's location panel should move to the newest fix.
4. On the phone, tap **Copy debug journal** and paste it somewhere safe
   for a moment. You are looking for LOCATION_RECAPTURE_STARTED followed by
   LOCATION_RECAPTURE_FIX with `outcome=POSTED_MOVEMENT`.
5. In the console, resolve the incident.
6. Walk another 100+ m. No new LOCATION_UPDATED entries should appear in
   the console journal. In the phone's debug journal you should find
   LOCATION_RECAPTURE_STOPPED with the reason
   "incident no longer active on the server". (This pack's build has no
   push messaging, so the stop lands within about a minute of the resolve.
   A push-enabled build would stop within seconds — either is a pass for
   the build you have.)

## Done looks like

- Walking during an active incident produced LOCATION_UPDATED entries with
  accuracy and age, and the console moved to the newest fix.
- After resolve, walking produced nothing new, and the phone recorded that
  it stopped watching.

## What to paste back

Fill in the task #274 block of `human/REPORT-BACK-FIELD-SESSION.txt`, paste
the phone's debug journal lines from steps 4 and 6, and copy the same two
results onto the "T2b movement re-capture" and "T2b stop on resolve" rows
of sheet 05's template (`human/REPORT-BACK-T2b-T10.txt`).
No token values, ever.
