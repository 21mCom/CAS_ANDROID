# Waiting-Tasks Operator Guide — START HERE

Pack: CAS-Waiting-Tasks-Guide v1 (assembled 2026-10-01)
Project: Covert Alert System (CAS)

## What this pack is

Thirteen pieces of work are paused. Some wait on you, some wait on the
Windows workstation that has the Pixel phone plugged in, and some just wait
for a computer helper (an "agent") to get a turn to run. This guide says
what each one needs, in what order, and exactly what to paste back into the
workspace chat when each is done.

## How to use this pack

- Print this file. It is the master checklist.
- The `human/` folder has one printable sheet per phone task. Print those
  too — each stands alone.
- The `agent/` folder holds technical handoff files for the computer
  agents. You never need to read them; the agents read them themselves.
- NOTHING in this pack contains passwords or tokens. When a step needs one,
  it comes from the separate message you already have. Never paste a token
  value into a report, the chat, or an email.

## The order to do things

1. PART 1 — one decision from you (about 2 minutes). It unblocks other work.
2. PART 2 — one phone session (about 1.5 to 2 hours) at the Windows
   workstation with the Pixel 11. One session clears six tasks, because the
   rebuilt test app only needs to be installed once.
3. PART 3 — tell the workspace agent to run the rest. You do nothing else
   for these.

---

## PART 1 — Your one decision (unblocks task #234, then #224)

The project's code lives in two places: this workspace and GitHub. The two
copies have drifted apart, so saving work to GitHub no longer works
normally. An agent can merge the two copies back into one. Done carelessly
that kind of merge can silently drop recent work, which is why it has been
waiting for your go-ahead. The safeguards are already written down for the
agent (review every removed line, re-run the full test suite afterwards,
prove a normal save works at the end).

What you do:

- [ ] Read the two sentences above.
- [ ] Reply in the workspace chat:

      Go ahead with task #234.

Done looks like: the agent reports that the workspace and GitHub share one
history again, and that a normal save (push) succeeded as proof.
After that, task #224 (turning on the "silently reverted work" alarm in
GitHub's checks) can run — no further action from you.

---

## PART 2 — One phone session (tasks #266, #272, #277, #274, #235, #290)

You need: the Windows workstation that ran the earlier phone tests, the
Pixel 11 and its USB-C cable, a responder phone that can receive texts,
about 60–75 minutes outdoors+indoors for the main proofs, and the message
holding the server address and tokens.

One time only:

- [ ] Copy the file `deliverables/CAS-Pixel11-Field-Proofs-T2b-T10-v0.8.0.zip`
      from the project onto the Windows workstation and extract it, e.g. to
      `Desktop\CAS-Pixel11-Field-Proofs`.
      (Note: the task list still names an older pack, v0.7.0. Ignore that —
      v0.8.0 is the right one. It has the newest phone app built in.)
- [ ] Install the rebuilt test app on the phone once: in the extracted
      folder, run `android-test-package\scripts\run-mvp-install.cmd` and
      type `INSTALL MVP` when asked. Sheet 01 has the details. Every sheet
      after this reuses the same install.

One rule applies to the whole session: before every send, check the console
and resolve any incident still open from the step before. An open incident
makes the next tap merge into it and skip the text message, which breaks
the checks the sheets are measuring. Each sheet reminds you at the right
spots.

Then work through the sheets in this order (each is one file in `human/`):

- [ ] Sheet 01 — task #266: prove a text message still sends when the
      phone's message-splitting feature fails.
- [ ] Sheet 02 — task #272: prove the one-line status under the Send button
      shows the final delivered/failed answer, including after the app is
      backgrounded and reopened.
- [ ] Sheet 03 — task #277: prove the front/back camera choice records
      labeled photos and videos.
- [ ] Sheet 04 — task #274: prove the phone re-sends its location when you
      walk 100+ m during an active incident, and stops after you resolve it.
- [ ] Sheet 05 — task #235: the main field-proofs run (location accuracy
      outdoors/indoors + evidence capture). Sheets 03 and 04 overlap with
      parts of this run — do each thing once and copy the same results into
      both report templates.
- [ ] Sheet 06 — task #290: prove the phone can update itself to a newer
      build with one tap. This one needs the workstation agent to build and
      publish the newer app file first; you only tap on the phone.

When the session is done:

- [ ] Paste the two filled-in report templates into the workspace chat:
      `human/REPORT-BACK-FIELD-SESSION.txt` (sheets 01–04 and 06) and
      `human/REPORT-BACK-T2b-T10.txt` (sheet 05). Blank copies are in the
      `human/` folder, and the same T2b/T10 template is inside the field
      pack ZIP. No token values in either one.

---

## PART 3 — Tasks the agents do (you don't need to do anything)

These run on computers, not on the phone. The technical handoff for each is
a file in `agent/`; the agents read those files themselves. Your only part
is to give the go-ahead and, at the end, read the results they paste back.

- [ ] Reply in the workspace chat:

      Go ahead with the waiting agent tasks #217, #222, #291, #292, and
      #308. Run #224 once #234 is finished.

What each one is, in plain words:

- #217 — Turn on a new safety check (it compares the server and the console
  so they can't drift apart) on GitHub's computers and confirm it passes
  there for the first time.
- #222 — Fix a practice drill that sometimes fails for the wrong reason
  (a slow pretend phone, not a real bug).
- #224 — After #234: switch on the "did any work get silently reverted?"
  sweep in GitHub's automatic checks.
- #291 — Confirm the phone-update safety checks pass on GitHub's computers
  for the first time.
- #292 — Make the console show which phone-update build the server is
  currently offering, so "what would phones install right now?" has an
  on-screen answer.
- #308 — Fix a known security warning in a third-party component
  (markdown-it) that is currently turning every GitHub check run red.

Done looks like: the agent pastes back a short result per task — green
check-run links for #217, #224, #291, #308; a passing drill log for #222;
and a screen description or shot for #292.

---

## If something goes wrong

- A step fails or looks different from the sheet: write down exactly what
  you saw (a photo of the phone screen is fine) and paste it into the
  workspace chat under "Blockers/questions". Do not keep retrying a failing
  step more than twice.
- The phone app misbehaves during a send or a recording: tap **Copy debug
  journal** in the app and paste that text too. Never paste token values.
- You are not sure which pack to use: it is
  `deliverables/CAS-Pixel11-Field-Proofs-T2b-T10-v0.8.0.zip`. Any other
  version number in older notes is out of date.
