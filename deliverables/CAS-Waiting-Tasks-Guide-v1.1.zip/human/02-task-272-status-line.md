# Sheet 02 — Task #272: The one-line status shows the final answer

Who does this: you, at the Windows workstation with the Pixel 11.
Time: about 15 minutes.

## Why

Under the **Send MVP alert now** button there is a single status line. It
exists so someone sending an alert in a panic does not have to read the
technical report: it should end on DELIVERED when every responder's text
goes through, or SMS_FAILED with a named reason when the phone's radio
reports a problem. It has only been proven in automated tests so far — this
sheet proves it on the real phone, including the failure case.

## What you need before starting

- Same as sheet 01: rebuilt app installed (version `0.8.0-selfupdate`),
  phone set up — including at least one responder number saved on the
  phone itself — responder phone nearby.
- A browser open at the console (the server address), only to resolve
  incidents between sends. The failure drill in step 2 does NOT touch the
  console — it works by switching the phone's own radio off.

## Golden rule for this sheet

Every step below needs its own fresh incident. Before each send, check the
console and resolve any incident still open from the step before. If an
incident is open, the tap merges into it, no new text goes out, and the
status line cannot show the result this sheet is checking.

## Steps

1. **Happy path.** Make sure the console's **Responders** page lists the
   correct responder number. On the phone, tap **Send MVP alert now** and
   watch the status line under the button until it stops changing (a few
   seconds). Write down exactly what it ends on — you want the word
   DELIVERED and the responder count. Then resolve the incident in the
   console.
2. **Failure path — airplane mode.** Do NOT change anything in the
   console: the server checks every saved number and rejects deliberately
   wrong ones, so a bad-number drill cannot reach the phone at all. This
   drill breaks the radio instead, which is the failure the status line
   exists to report. On the phone, pull down the quick settings, turn on
   **Airplane mode**, and then turn **Wi-Fi off** as well — Android can
   quietly keep Wi-Fi on in airplane mode, and as long as the phone has
   any internet it can still reach the server (and Wi-Fi calling can
   still carry texts), which defeats the drill. Confirm the phone is
   really offline: no Wi-Fi symbol, no signal bars. Tap **Send MVP alert
   now** and watch the status line. With no connection the phone cannot
   reach the server, so it falls back to the responder number saved on
   the phone itself and tries the radio directly — and the radio is off.
   The line should end on SMS_FAILED with a named radio reason: most
   phones answer RESULT_ERROR_RADIO_OFF within seconds; if the radio
   stays silent, the app's watchdog closes the send as NO_RADIO_RESULT
   after about 45 seconds. Either named failure is a pass — write down
   the exact wording. If the line instead ends on DELIVERED, the phone
   was still online: resolve that incident in the console, double-check
   Wi-Fi is off, and repeat the step. **Restore:** turn Airplane mode
   back off, turn Wi-Fi back on if you use it, and wait for the signal
   bars to return. When the drill works as written, nothing was created
   on the server (the phone never reached it), so there is no incident to
   resolve and no console setting to change back for this step.
3. **Background and resume.** Send one more alert and immediately press
   the phone's home button so the app goes to the background. Wait about 15
   seconds, then reopen the app. The status line should already show the
   final answer (DELIVERED) — it catches up when the app comes back.
   Resolve the incident in the console.

## Done looks like

- Step 1 ended with the line reading DELIVERED with the responder count.
- Step 2 ended with SMS_FAILED naming the radio's error (e.g.
  RESULT_ERROR_RADIO_OFF, or NO_RADIO_RESULT after the watchdog), reached
  with Airplane mode on — and Airplane mode was switched back off
  afterwards.
- Step 3 showed the final outcome after reopening the app.

## What to paste back

Fill in the task #272 block of `human/REPORT-BACK-FIELD-SESSION.txt`: the
exact status-line wording for all three steps. If any step misbehaved, tap
**Copy debug journal** in the app and paste that text as well.
No token values, ever.
